package exam.question4;

import oops.Vehi;

public class mai {
    public static void main(String[] args) {
        Vehicle v = new Car();
        v.start();
        Vehicle v2 = new Vehicle();
        v2.start();
    }
}
