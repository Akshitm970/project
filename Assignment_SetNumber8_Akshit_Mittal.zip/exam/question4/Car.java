package exam.question4;

public class Car extends Vehicle {
    void start() {
        System.out.println("Starting Car");
        super.start();

    }

}
