package exam.question4;

public class Vehicle {
    void start(){
        System.out.println("Starting Vehicle");
    }
    String brand;
}
