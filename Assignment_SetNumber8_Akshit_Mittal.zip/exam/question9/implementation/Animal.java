package exam.question9.implementation;

public abstract class Animal {
    public abstract void makesound() ;
    public void eat(){
        System.out.println("eating");
    }

}
