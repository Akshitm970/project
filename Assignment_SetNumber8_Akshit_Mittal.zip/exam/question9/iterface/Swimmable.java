package exam.question9.iterface;

public interface Swimmable {
    void swim();
}
