package exam.question9.iterface;

public interface Flyable {
    void fly();

}
