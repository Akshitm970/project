package exam.question6;

public class mai {
    public static void main(String[] args) {
     Employee e1 = new Employee();
     e1.setId(1);
     e1.setName("Akm");
     e1.setSalary(5000);
     e1.displayInfo();
    }
}
