package exam.question6;

public class Manager extends Employee {
    int teamSize;

    @Override
    void displayInfo() {
        super.displayInfo();
    }
}
